/*
NAME : Poojashree MN
DATE : 29/09/24
DESCRIPTION : contact.h - all function prototypes and structure defintion and structure declaration
*/
#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {
    Contact contacts[100];
    int contactCount;
    Contact temp;
    Contact temp1;
} AddressBook;

void createContact(AddressBook *addressBook);
int searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook, int sortCriteria);
void initialize(AddressBook *addressBook);
void saveContactsToFile(AddressBook *AddressBook);
int val(char *s);
int valnum(char *s);
int valemail(const char *email);
#endif