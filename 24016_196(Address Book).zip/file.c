/*
NAME : Poojashree MN
DATE : 29/09/24
DESCRIPTION : file.c - all file function defintions 
*/
#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook)
{
        FILE *temp= fopen("temp.csv","w");
        for(int i=0;i<addressBook->contactCount;i++)
        {
            fprintf(temp,"%s,%s,%s\n",addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
        }
        fclose(temp);
        remove("text.csv");
        rename("temp.csv","text.csv");
}
int loadContactsFromFile(AddressBook *addressBook)
{
        FILE *file=fopen("text.csv","r");
         if (file == NULL) 
	 {
        perror("Error opening file");
        return -1; // Return -1 on failure
    	}	
        int i=0;
	char line[100];
    // Read each line and parse it
    while (i < 100 && fgets(line, sizeof(line), file) != NULL) 
    {
        // Use sscanf to extract name, phone, and email from the line
        if (sscanf(line, "%[^,],%[^,],%s",
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email) == 3) {
            i++;
	}
    }
    addressBook->contactCount = i; // Update contact count
    fclose(file); // Close the file
    return i; // Return the number of contacts loaded        {
}