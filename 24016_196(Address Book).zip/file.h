/*
NAME : Poojashree MN
DATE : 29/09/24
DESCRIPTION : CONTACT.C - all file function prototypes 
*/
#ifndef FILE_H
#define FILE_H

#include "contact.h"

void saveContactsToFile(AddressBook *addressBook);
int loadContactsFromFile(AddressBook *addressBook);

#endif