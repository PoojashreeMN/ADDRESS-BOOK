/*
NAME : Poojashree MN
DATE : 29/09/24
DESCRIPTION : CONTACT.C - all function defintions 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
//funtion to validate name
int val(char *s) {
    int i = 0;
    while (s[i] != '\0') {
	    //name must contain only alphabet and space
        if (!((isalpha(s[i])) || s[i] == ' ')) {              
            return 0;
        }
        i++;
    }
    return 1;
}
//function to validate number
int valnum(char *s) {
    int i = 0;
    while (s[i] != '\0') {
	    //number must be 10 characeters and they are only digits 
        if (!(isdigit(s[i])) || strlen(s) != 10) {              
            return 0;
        }
        i++;
    }
    return 1; 
}
// Function to validate the email address
int valemail(const char *email) {
    int at_count = 0;
    int length = strlen(email);

    for (int i = 0; i < length; i++) {
        char c = email[i];

        // Check for valid characters
        if (!isalnum(c) && c != '@' && c != '.' && c != '-' && c != '_') {
            return 0;  
        }

        // Count '@' characters
        if (c == '@') {
            at_count++;
            if (at_count > 1) return 0;  
        }

        // Check for a period after '@'
        if (c == '.' && (i > 0 && email[i - 1] == '@')) {
            return 0;  // No valid domain if '.' immediately follows '@'
        }
    }

    // Check for exactly one '@' and at least one '.' after '@'
    char *at_ptr = strchr(email, '@');
    char *dot_ptr = strrchr(email, '.');

    if (at_ptr == NULL || dot_ptr == NULL || dot_ptr < at_ptr) {
        return 0;  // Missing '@' or '.' before '@'
    }

    // Check domain is not empty
    if (strlen(dot_ptr + 1) == 0) return 0;

    return 1;  // Passed all checks
}
void listContacts(AddressBook *addressBook, int sortCriteria) 
{
    // Sort contacts based on the chosen criteria
    //arranges based on alphabetical order
if(sortCriteria)
    {
    int n = addressBook->contactCount;
    // bubble sort mechanism
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (strcmp(addressBook->contacts[i].name, addressBook->contacts[j].name) > 0) {
                Contact temp = addressBook->contacts[i];
                addressBook->contacts[i] = addressBook->contacts[j];
                addressBook->contacts[j] = temp;
            }
        }
    }
    }
    //to print all the contacts 
    if(addressBook->contactCount)
    {
	printf("--------------------------------------------- # DETAILS # ----------------------------------------------------\n");
    printf("--------------------------------------------------------------------------------------------------------------\n");
    printf("| %-40s | %-15s | %-45s |\n","Name","Number","Email");
	printf("--------------------------------------------------------------------------------------------------------------\n");
    for (int i = 0; i < addressBook->contactCount; i++)
	{
        printf("| %-40s | %-15s | %-45s |\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
	 printf("--------------------------------------------------------------------------------------------------------------\n");
    	}	
    }
    else{
        printf("-------- # No contact details to show # --------");
    }    
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
  //  populateAddressBook(addressBook);
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}
void saveAndExit(AddressBook *addressBook)
{
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}

void createContact(AddressBook *addressBook)
{
	/* Define the logic to create a Contacts */
    int i=addressBook->contactCount;
    getchar();
    printf("Enter your name : ");
    scanf("%[^\n]",addressBook->contacts[i].name);
    getchar();
    if(!val(addressBook->contacts[i].name)) //validate name function call 
    {
       printf("\tError : Invalid name\n");
       return;
    }
    printf("Enter your number : ");
    scanf("%[^\n]",addressBook->contacts[i].phone);
    getchar();
    //validate number function call
     if(!valnum(addressBook->contacts[i].phone))                                                                                          {                                                                                                                                       printf("\tError : Invalid number\n");                                                                                                return;                                                                                                                           }
     int c=0;
     //checks if number already exists
            for(int j=0;j<addressBook->contactCount;j++)
            {
                if(strcmp(addressBook->contacts[j].phone,addressBook->contacts[i].phone)==0)
                {
                    c=1;
		    break;
		}
	    }

    if(c!=0)
    {
	    printf("\tNumber already exists\n");
	    return;
    }
    printf("Enter your email-address : ");
    scanf("%[^\n]",addressBook->contacts[i].email);
    getchar();
    //validate email function call
    if(!valemail(addressBook->contacts[i].email))
    {
       printf("\tError : Invalid e-mail\n");
       return;
    }
    //checks if email exists alraedy
    for(int j=0;j<addressBook->contactCount;j++)
        {
        if(strcmp(addressBook->contacts[j].email,addressBook->contacts[i].email)==0)
        {
            c=1;
            break;
            }
        }
	 
     if(c!=0)
    {
            printf("\tE-mail already exists\n");
            return;
    }
    addressBook->contactCount++;
    printf("\tContact created successfully!\n");
}

int searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
	printf("Do you want to search by : \n1.Name\n2.Number\n3.Email \n");
    int opt;
    scanf("%d",&opt);
    getchar();
    switch(opt)
    {
	    //To search based on name
        case 1:
        {
            printf("Enter the name : ");
            scanf("%[^\n]",addressBook->temp.name);
            getchar();
	    //to check the name irrespective case
	    for (int j = 0; addressBook->temp.name[j] != '\0'; j++) addressBook->temp.name[j] = toupper((unsigned char)addressBook->temp.name[j]);
	    //to validate name function call
            if(!val(addressBook->temp.name))
            {
            printf("\tError : Invalid name");
            return -1;
            }
            int c=0,index;
	     for(int i=0;i<addressBook->contactCount;i++)
            {
	    strcpy(addressBook->temp1.name,addressBook->contacts[i].name);
	    //to convert present ith row name to upper and then compare
            for (int j = 0; addressBook->temp1.name[j] != '\0'; j++) addressBook->temp1.name[j] = toupper((unsigned char)addressBook->temp1.name[j]);
                if(strstr(addressBook->temp1.name,addressBook->temp.name)!=NULL)
                {
                    index=i;
                    if(c==0)
		    {
      printf("--------------------------------------------------------------------------------------------------------------\n");
	  printf("| %-40s | %-15s | %-45s |\n","Name","Number","Email");
      printf("--------------------------------------------------------------------------------------------------------------\n");
		    } 
      printf("| %-40s | %-15s | %-45s |\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
      printf("--------------------------------------------------------------------------------------------------------------\n");
                    c++;
                }
            }
            if(c==0)
            {
                printf("\t--- No contacts found ---\n");
                return -1;
            }
            if(c==1)
	//if only one contact found return index value
            return index;
            if(c!=1)
            {
		    //if there are multiple contacts with same names
                printf("Multiple results for your name \nDo you want to search by \n2.number\n3.Email\n");
                scanf("%d",&opt);
                getchar();
                if(opt==2)  //reusing the code of search by number
                goto case_2;
                else if(opt==3)  //reusing the code of search by email
                goto case_3;
                else
                goto def;
            }
            break;
        }
	//to search based on number
        case 2:
           case_2:
           {
            printf("Enter mobile number : ");
            scanf("%[^\n]",addressBook->temp.phone);
            getchar();
            if(!valnum(addressBook->temp.phone))  //validate number function call
            {
            printf("\tError : Invalid number");
            return -1;
            }
            int c=0;
            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->temp.phone,addressBook->contacts[i].phone)==0)
                {
                    c++;
		  printf("-------------------------------------------- # CONTACT DETAILS # --------------------------------------------\n");
          printf("--------------------------------------------------------------------------------------------------------------\n");
		    printf("| %-40s | %-15s | %-45s |\n","Name","Number","Email");
          printf("--------------------------------------------------------------------------------------------------------------\n");
          printf("| %-40s | %-15s | %-45s |\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
          printf("--------------------------------------------------------------------------------------------------------------\n");
		     return i;
                }
            }
            if(c==0)
            {
            printf("No contact found\n");
            return -1;
            }
            break;
        }
	   //to search based on email
        case 3:
        case_3:
        {
            printf("Enter the E-mail : ");
            scanf("%[^\n]",addressBook->temp.email);
            getchar();
	    //validate email function call
            if(!valemail(addressBook->temp.email))
            {
            printf("\tError : Invalid email");
            return -1;
            }
            int c=0;
            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->temp.email,addressBook->contacts[i].email)==0)
                {
                    c++;
	printf("--------------------------------------------------------------------------------------------------------------\n");
        printf("| %-40s | %-15s | %-45s |\n","Name","Number","Email");
        printf("--------------------------------------------------------------------------------------------------------------\n");
	printf("| %-40s | %-15s | %-45s |\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        printf("--------------------------------------------------------------------------------------------------------------\n");
		    return i;
                }
            }
            if(c==0)
            {
            printf("\tNo contact found.\n");
            return -1;
            }
           break;
        }
        default:
        def:
        printf("\tInvalid choice\n");
	break;
    }
}

void editContact(AddressBook *addressBook)
{
	/* Define the logic for Editcontact */
	//calling search funtion and collects index value to edit
    int i=searchContact(addressBook);
	if(i==-1)
	{
	    printf("Editing is not possible\n");
	    return;
	}
	int op;
	printf("Do you modify name(1) or skip(0)\n");
	scanf("%d",&op);
	getchar();
	//if you choose to modify name
	if(op)
	{	
	printf("Enter modified name :\n");
    scanf("%[^\n]",addressBook->temp.name);
    	getchar();
    	//validate name of new input
    	if(!val(addressBook->temp.name))
    	{
       	printf("\tError : Invalid name.\n");
       	return;
    	}
    	//if there is no error name gets modified and stored
    		strcpy(addressBook->contacts[i].name,addressBook->temp.name);
	}
	do{
	//if you choose to modify number
	printf("Do you modify number(1) or skip(0)\n");
	scanf("%d",&op);
    int c=0; 
	getchar();
	if(op)
	{
    	printf("Enter your modified phone number : \n");
    	scanf("%[^\n]",addressBook->temp.phone);
    	getchar();
        //call function valnum 
    	if(!valnum(addressBook->temp.phone))
    	{	
       		printf("Error : Invalid number.\n");
       		op=0;
    	}
        //to check if number already exists
	    for(int j=0;j<addressBook->contactCount;j++)                                                                                         
        {                                                                                                                                        
        if(strcmp(addressBook->contacts[j].phone,addressBook->temp.phone)==0)     
		{        
		    c=1; 
		   printf("Number already exists\n");	
		} 
	}
	
    if(c==0)
    {
        //if num is not already present then update
	    strcpy(addressBook->contacts[i].phone,addressBook->temp.phone);
        op=0;
    }
    }
    //loops continues untill number not exits or skip editing
	}while(op);
    //check if update email
    do
    {    
	printf("Do you modify E-mail(1) or skip(0)\n");
	scanf("%d",&op);
    int c=0;
	getchar();
	if(op)
	{
    printf("Enter your modified email-address : ");
    scanf("%[^\n]",addressBook->temp.email);
    getchar();
    //validate email function call
    if(!valemail(addressBook->temp.email))
    {
       printf("Error : Invalid e-mail.\n");
       return;
    }
    //check if same email alraedy presents
    for(int j=0;j<addressBook->contactCount;j++)
        {
            if(strcmp(addressBook->contacts[j].email,addressBook->temp.email)==0)
            {
               c=1;
               printf("\tE-Mail Already exist\n");
               break;
            }
        }
    if(c==0)
    {
        //if email is not present
    strcpy(addressBook->contacts[i].email,addressBook->temp.email);
    op=0;
	}
    }
    }while(op);
    printf("Contact updated successfully!\n");

}
//function to delete a contact
void deleteContact(AddressBook *addressBook)
{
	/* Define the logic for deletecontact */
		int index = searchContact(addressBook);
        //returns the index of particular contact
	 if (index < 0 || index >= addressBook->contactCount) 
	{
        //checks if index position is in correct range 
        printf("Deletion is not possible.\n");
        return;
    }

    // Shift elements to the left to fill the gap
    for (int i = index; i < addressBook->contactCount - 1; i++) {
        addressBook->contacts[i] = addressBook->contacts[i + 1];
    }

    // Decrease the contact count
    addressBook->contactCount--;

    printf("Contact deleted successfully.\n");
   
}